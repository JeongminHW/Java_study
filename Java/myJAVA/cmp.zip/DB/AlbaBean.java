package cmp.DB;

public class AlbaBean {
	private String id;
	private String pw;
	private String name;
	private String birthday;
	private String phone;
	private String part_time;
	private boolean workcheck;
	private int totalwork;
	
	public String getid() {
		return id;
	}
	public void setid(String id) {
		this.id = id;
	}
	
	public String getpw() {
		return pw;
	}
	public void setpw(String pw) {
		this.pw = pw;
	}
	
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	
	public String getbirthday() {
		return birthday;
	}
	public void setbirthday(String birthday) {
		this.birthday = birthday;
	}
	
	public String getphone() {
		return phone;
	}
	public void setphone(String phone) {
		this.phone = phone;
	}
	
	public String getPart_time() {
		return part_time;
	}
	public void setPart_time(String part_time) {
		this.part_time = part_time;
	}
	
	public boolean isWorkcheck() {
		return workcheck;
	}
	public void setWorkcheck(boolean workcheck) {
		this.workcheck = workcheck;
	}
	
	public int getTotalwork() {
		return totalwork;
	}
	public void setTotalwork(int totalwork) {
		this.totalwork = totalwork;
	}
	
	

}

package cmp.DB;

import java.sql.*;
import cmp.DB.DBConnectionMgr;


public class DBMgr {
	private DBConnectionMgr pool;
	
	Connection con = null;
	Statement stmt = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = null;
	
	public DBMgr() {
		try {
			pool = DBConnectionMgr.getInstance();
			System.out.println("연결 성공");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// 직원 로그인
	public boolean EmployeeLoginCheck(String id, String pw) {
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "select em_pw from employee where em_id = ? and em_pw = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				if(pw.equals(rs.getString("em_pw"))) {
					flag = true;
				}
				else {
					flag = false;
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			pool.freeConnection(con, pstmt, rs); //con는 반납, pstmt/rs는 close
		}
		
		return flag;
	}
	
	// 알바 로그인
	public boolean AlbaLoginCheck(String id, String pw) {
		boolean flag = false;
		try {
			sql = "select alba_pw from employee where alba_id = ? and alba_pw = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				if(pw.equals(rs.getString("alba_pw"))) {
					flag = true;
				}
				else {
					flag = false;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}

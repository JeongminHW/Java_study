package cmp.GUI;

import javax.swing.*;
import java.awt.*;

public class EmSignUp {
	
	public EmSignUp() {
		JFrame frame = new JFrame("Staff Sign Up");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 500);
        
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(9, 1, 5, 5));
        
        JTextField idField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);
        JPasswordField confirmPasswordField = new JPasswordField(20);
        JTextField nameField = new JTextField(20);
        JTextField birthDateField = new JTextField(20);
        JTextField phoneNumberField = new JTextField(20);
        
        String[] parts = {"Part A", "Part B", "Part C"};
        JComboBox<String> partComboBox = new JComboBox<>(parts);
        
        String[] ranks = {"Rank 1", "Rank 2", "Rank 3"};
        JComboBox<String> rankComboBox = new JComboBox<>(ranks);
        
        JButton submitButton = new JButton("확인");
        
        panel.add(createLabeledPanel("ID", idField));
        panel.add(createLabeledPanel("Password", passwordField));
        panel.add(createLabeledPanel("Password Confirm", confirmPasswordField));
        panel.add(createLabeledPanel("Name", nameField));
        panel.add(createLabeledPanel("Birth date", birthDateField));
        panel.add(createLabeledPanel("Phone Number", phoneNumberField));
        panel.add(createLabeledPanel("Part", partComboBox));
        panel.add(createLabeledPanel("Rank", rankComboBox));
        panel.add(submitButton);
        
        frame.add(panel);
        frame.setVisible(true);
	}
    
    private static JPanel createLabeledPanel(String label, JComponent component) {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel jLabel = new JLabel(label);
        panel.add(jLabel, BorderLayout.WEST);
        panel.add(component, BorderLayout.CENTER);
        return panel;
    }
    
    public static void main(String[] args) {
		new EmSignUp();
	}
}
